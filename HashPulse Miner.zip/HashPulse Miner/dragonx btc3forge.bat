@echo off
cd /d "%~dp0"
HashPulse.exe --coin dragonx --pool stratum+tcp://btc3forge.com:3335 --address VOTRE_ADRESSE_DRAGONX --worker rig_01
pause
