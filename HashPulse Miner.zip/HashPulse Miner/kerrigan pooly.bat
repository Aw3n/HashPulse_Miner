@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --pool stratum+tcp://pooly.ca:3202 --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause