@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --pool stratum+ssl://veinpool.fr:13280 --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause