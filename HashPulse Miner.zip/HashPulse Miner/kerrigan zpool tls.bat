@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --pool stratum+ssl://equihash192.mine.zpool.ca:52192 --password c=KRGN --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause