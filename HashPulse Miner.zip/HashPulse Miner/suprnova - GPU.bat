@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://xel.suprnova.cc:3333 --address xel:VOTRE_ADRESSE --gpu --worker monGPU
pause
