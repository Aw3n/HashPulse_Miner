@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://xel-eu.baikalmine.com:9030 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
