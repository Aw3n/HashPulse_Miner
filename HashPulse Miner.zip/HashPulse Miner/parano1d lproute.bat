@echo off
cd /d "%~dp0"
HashPulse.exe --coin parano1d --pool stratum+ssl://ru.lproute.com:3338 --no-ssl-verify --address VOTRE_ADRESSE_PARANO1D --worker rig_01
pause
