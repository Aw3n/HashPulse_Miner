@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --pool stratum+tcp://pool.nitopool.online:3057 --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause