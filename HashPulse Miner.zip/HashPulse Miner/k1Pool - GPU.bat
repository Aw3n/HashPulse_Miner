@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://eu.xel.k1pool.com:9351 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
