@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://eu1.1miner.net:4073 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
