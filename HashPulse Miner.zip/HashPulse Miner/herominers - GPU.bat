@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://xelis.herominers.com:1225 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
