@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --gpu --pool stratum+tcp://mine.kerriganpool.com:7203 --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause