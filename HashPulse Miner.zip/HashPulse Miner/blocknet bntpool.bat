@echo off
cd /d "%~dp0"
HashPulse.exe --coin blocknet --pool stratum+tcp://bntpool.com:3333 --address C4S9375DuQT3k6NZzBJcSNXovKBZs1aijN2PNY4wk6ELUr9K43bkHAGDpVhJxan1SupRvLwVJy2CArC6rj5yMhUYNuZjt --worker rig_01
pause
