@echo off
cd /d "%~dp0"
HashPulse.exe --coin firo --pool stratum+tcp://firo.cedric-crispin.com:4064 --address VOTRE_ADRESSE_FIRO --worker rig_01
pause
