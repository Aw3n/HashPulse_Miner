@echo off
cd /d "%~dp0"
HashPulse.exe --coin dragonx --pool stratum+tcp://pool.dragonx.is:3433 --address VOTRE_ADRESSE_DRAGONX --worker rig_01
pause
