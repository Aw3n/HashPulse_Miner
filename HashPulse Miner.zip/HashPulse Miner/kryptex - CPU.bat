@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://xel-eu.kryptex.network:7019 --address xel:VOTRE_ADRESSE --worker rig_01
pause
