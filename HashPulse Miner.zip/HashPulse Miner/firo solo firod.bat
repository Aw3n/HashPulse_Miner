@echo off
cd /d "%~dp0"
HashPulse.exe --coin firo --daemon http://127.0.0.1:8382 --rpc-user VOTRE_RPCUSER --rpc-pass VOTRE_RPCPASSWORD --address VOTRE_ADRESSE_FIRO --worker rig_01
pause
