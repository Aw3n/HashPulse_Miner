@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --pool stratum+tcp://equihash192.mine.zpool.ca:2192 --password c=KRGN --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause