@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://fr.vipor.net:5077 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
