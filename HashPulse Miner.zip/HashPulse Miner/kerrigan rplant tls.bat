@echo off
cd /d "%~dp0"
HashPulse.exe --coin kerrigan --gpu --pool stratum+ssl://eu.rplant.xyz:17040 --address VOTRE_ADRESSE_KERRIGAN --worker rig_01
pause