@echo off
cd /d "%~dp0"
HashPulse.exe --coin firo --pool stratum+ssl://firo.cedric-crispin.com:4065 --address VOTRE_ADRESSE_FIRO --worker rig_01
pause
