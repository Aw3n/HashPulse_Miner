@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://xel.kryptex.network:7019 --address xel:VOTRE_ADRESSE --gpu --worker rig_01
pause
