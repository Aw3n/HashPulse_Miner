@echo off
cd /d "%~dp0"
HashPulse.exe --pool stratum+tcp://fr.grandpool.io:2025 --address xel:VOTRE_ADRESSE --worker rig_01 --user-agent "rigel/1.4.5" --gpu
pause
