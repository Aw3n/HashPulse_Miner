@echo off
cd /d "%~dp0"
HashPulse.exe --coin parano1d --pool stratum+ssl://eu2.innovlab.cc:19601 --address VOTRE_ADRESSE_PARANO1D --worker rig_01
pause
