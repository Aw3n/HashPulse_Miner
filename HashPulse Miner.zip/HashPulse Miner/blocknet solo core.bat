@echo off
cd /d "%~dp0"
HashPulse.exe --coin blocknet --daemon http://127.0.0.1:8332 --address VOTRE_ADRESSE_BLOCKNET --worker rig_01
pause
