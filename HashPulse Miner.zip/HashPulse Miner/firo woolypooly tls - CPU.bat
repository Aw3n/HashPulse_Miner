@echo off
cd /d "%~dp0"
HashPulse.exe --coin firo --pool stratum+ssl://pool.woolypooly.com:3105 --address VOTRE_ADRESSE_FIRO --worker rig_01
pause
