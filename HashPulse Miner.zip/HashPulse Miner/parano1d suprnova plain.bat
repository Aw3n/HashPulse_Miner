@echo off
cd /d "%~dp0"
HashPulse.exe --coin parano1d --pool stratum+tcp://noid.suprnova.cc:3337 --address VOTRE_ADRESSE_PARANO1D --worker rig_01
pause
