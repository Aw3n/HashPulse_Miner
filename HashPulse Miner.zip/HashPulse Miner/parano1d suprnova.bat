@echo off
cd /d "%~dp0"
HashPulse.exe --coin parano1d --pool stratum+ssl://noid.suprnova.cc:3341 --address VOTRE_ADRESSE_PARANO1D --worker rig_01
pause
